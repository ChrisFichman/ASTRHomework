from numpy import *
from matplotlib import *
from pylab import *
from math import *

